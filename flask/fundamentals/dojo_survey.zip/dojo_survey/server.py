from logging import fatal
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'jflkajljfioefuirf564656465465465f4654g655g56r4g54'

@app.route('/')
def  index():
    return render_template("index.html")

@app.route('/process', methods = ['POST'])
def survey():
    session["survey_name"] = request.form.get("name", False)
    session["survey_location"] = request.form.get("location", False)
    session["survey_language"] = request.form.get("language",False)
    session["survey_comment"] = request.form.get("comment",False)
    return redirect('/result')

@app.route('/result')
def results():
    return render_template("result.html", result_name = session["survey_name"], result_location = session["survey_location"], result_language = session["survey_language"], result_comment = session["survey_comment"])



if __name__=="__main__":
    app.run(debug=True)