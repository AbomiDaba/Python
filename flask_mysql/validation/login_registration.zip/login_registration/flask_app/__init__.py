from flask import Flask, flash

app = Flask(__name__)
